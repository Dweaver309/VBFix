Option Explicit On
Option Strict On

Imports Microsoft.SPOT
Imports System
Imports Microsoft.SPOT.Hardware
Imports Microsoft.VisualBasic

Namespace $safeprojectname$

    Public Module Module1

        Sub Main()

            Debug.Print(Resources.GetString(Resources.StringResources.String1))

        End Sub

    End Module

End Namespace